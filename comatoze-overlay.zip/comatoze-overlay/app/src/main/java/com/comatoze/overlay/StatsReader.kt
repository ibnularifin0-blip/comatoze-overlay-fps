package com.comatoze.overlay

import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import android.os.SystemClock
import java.io.File
import kotlin.math.roundToInt

data class Stats(
    val cpu: Int?,
    val gpu: Int?,
    val ram: Int?,
    val tempC: Float?,
    val battery: Int?,
    val fps: Int?
)

class StatsReader(private val ctx: Context) {
    private val am = ctx.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
    private val fpsReader = FpsReader(ctx.packageName)

    private var prevTotal = 0L
    private var prevIdle = 0L
    private var gpuPath: String? = null

    private val gpuPaths = listOf(
        "/sys/class/kgsl/kgsl-3d0/gpu_busy_percentage",
        "/sys/class/kgsl/kgsl-3d0/gpubusy",
        "/sys/kernel/gpu/gpu_busy",
        "/sys/class/misc/mali0/device/utilisation",
        "/sys/devices/platform/mali/utilisation",
        "/proc/mali/utilization"
    )

    fun read(enabled: Set<Metric>): Stats {
        val cpu = if (Metric.CPU in enabled) readCpu() else null
        val gpu = if (Metric.GPU in enabled) readGpu() else null
        val ram = if (Metric.RAM in enabled) readRam() else null
        val fps = if (Metric.FPS in enabled) fpsReader.fps() else null

        var temp: Float? = null
        var level: Int? = null
        if (Metric.TEMP in enabled || Metric.BATT in enabled) {
            val i = ctx.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
            if (i != null) {
                val t = i.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, Int.MIN_VALUE)
                if (t != Int.MIN_VALUE) temp = t / 10f
                val l = i.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
                val s = i.getIntExtra(BatteryManager.EXTRA_SCALE, -1)
                if (l >= 0 && s > 0) level = l * 100 / s
            }
        }
        return Stats(cpu, gpu, ram, temp, level, fps)
    }

    private fun readFile(path: String): String? {
        try {
            val t = File(path).readText()
            if (t.isNotBlank()) return t
        } catch (_: Exception) {
        }
        val viaRoot = RootShell.run("cat $path 2>/dev/null")
        return if (viaRoot != null && viaRoot.isNotBlank()) viaRoot else null
    }

    private fun readCpu(): Int? {
        val text = readFile("/proc/stat") ?: return null
        val line = text.lineSequence().firstOrNull { it.startsWith("cpu ") } ?: return null
        val p = line.trim().split(Regex("\\s+")).drop(1).mapNotNull { it.toLongOrNull() }
        if (p.size < 4) return null
        val idle = p[3] + (if (p.size > 4) p[4] else 0L)
        val total = p.take(8).sum()
        val dTotal = total - prevTotal
        val dIdle = idle - prevIdle
        val first = prevTotal == 0L
        prevTotal = total
        prevIdle = idle
        if (first || dTotal <= 0) return null
        return ((dTotal - dIdle) * 100 / dTotal).toInt().coerceIn(0, 100)
    }

    private fun parseGpu(path: String, text: String): Int? {
        val nums = Regex("\\d+").findAll(text).map { it.value.toLong() }.toList()
        if (nums.isEmpty()) return null
        if (path.endsWith("gpubusy") && nums.size >= 2) {
            if (nums[1] <= 0L) return 0
            return (nums[0] * 100 / nums[1]).toInt().coerceIn(0, 100)
        }
        return nums[0].toInt().coerceIn(0, 100)
    }

    private fun readGpu(): Int? {
        val known = gpuPath
        if (known != null) {
            val t = readFile(known) ?: return null
            return parseGpu(known, t)
        }
        for (p in gpuPaths) {
            val t = readFile(p) ?: continue
            val v = parseGpu(p, t)
            if (v != null) {
                gpuPath = p
                return v
            }
        }
        return null
    }

    private fun readRam(): Int? {
        val mi = ActivityManager.MemoryInfo()
        am.getMemoryInfo(mi)
        if (mi.totalMem <= 0L) return null
        return ((mi.totalMem - mi.availMem) * 100 / mi.totalMem).toInt().coerceIn(0, 100)
    }
}

/**
 * FPS aplikasi di layar lewat SurfaceFlinger. Butuh root.
 * Alurnya: cari paket yang sedang fokus, cari layer miliknya, lalu hitung frame
 * yang tampil dalam 1 detik terakhir dari `dumpsys SurfaceFlinger --latency`.
 */
class FpsReader(private val selfPkg: String) {
    private var layer: String? = null
    private var layerPkg: String? = null
    private var lastDetect = 0L

    fun fps(): Int? {
        if (RootShell.available != true) return null
        val now = SystemClock.elapsedRealtime()
        if (now - lastDetect > 3000) {
            lastDetect = now
            val pkg = focusedPackage()
            if (pkg != layerPkg) {
                layerPkg = pkg
                layer = null
            }
            if (layer == null && pkg != null && pkg != selfPkg) {
                layer = findLayer(pkg)
            }
        }
        val l = layer ?: return null
        val result = measure(l)
        if (result == null) {
            layer = null
            lastDetect = 0L
        }
        return result
    }

    private fun focusedPackage(): String? {
        val out = RootShell.run("dumpsys window | grep -E 'mCurrentFocus|mFocusedApp'") ?: return null
        val m = Regex("u\\d+\\s+([A-Za-z0-9_.]+)/").find(out) ?: return null
        return m.groupValues[1]
    }

    private fun findLayer(pkg: String): String? {
        val out = RootShell.run("dumpsys SurfaceFlinger --list") ?: return null
        val candidates = out.lines()
            .map { it.trim() }
            .filter { it.contains(pkg) && !it.startsWith("Background") }
            .sortedBy { if (it.startsWith("SurfaceView")) 0 else 1 }
            .take(4)
        for (c in candidates) {
            if (measure(c) != null) return c
        }
        return null
    }

    private fun measure(layerName: String): Int? {
        val quoted = layerName.replace("\\", "\\\\").replace("\"", "\\\"")
        val out = RootShell.run("dumpsys SurfaceFlinger --latency \"$quoted\"") ?: return null
        val times = ArrayList<Long>()
        for (line in out.lines().drop(1)) {
            val parts = line.trim().split(Regex("\\s+"))
            if (parts.size < 3) continue
            val t = parts[1].toLongOrNull() ?: continue
            if (t > 0L && t != Long.MAX_VALUE) times.add(t)
        }
        if (times.size < 2) return null
        times.sort()
        val last = times.last()
        val window = times.filter { it >= last - 1_000_000_000L }
        if (window.size < 2) return window.size
        val span = window.last() - window.first()
        if (span <= 0L) return null
        return ((window.size - 1) * 1_000_000_000.0 / span).roundToInt()
    }
}
