package com.comatoze.overlay

import android.content.Context
import android.content.SharedPreferences

enum class Metric(val key: String, val label: String, val iconRes: Int, val defaultOn: Boolean) {
    CPU("cpu", "CPU", R.drawable.ic_cpu, true),
    GPU("gpu", "GPU", R.drawable.ic_gpu, true),
    RAM("ram", "RAM", R.drawable.ic_ram, false),
    TEMP("temp", "Suhu", R.drawable.ic_temp, true),
    BATT("batt", "Baterai", R.drawable.ic_battery, false),
    FPS("fps", "FPS", R.drawable.ic_fps, true)
}

class Prefs(context: Context) {
    val sp: SharedPreferences = context.getSharedPreferences("comatoze", Context.MODE_PRIVATE)

    /** 0 = Mini, 1 = Standar, 2 = Lengkap */
    var style: Int
        get() = sp.getInt("style", 0)
        set(v) {
            sp.edit().putInt("style", v).apply()
        }

    /** Opasitas latar overlay, 30..100 */
    var alpha: Int
        get() = sp.getInt("alpha", 86)
        set(v) {
            sp.edit().putInt("alpha", v).apply()
        }

    var posX: Int
        get() = sp.getInt("pos_x", -1)
        set(v) {
            sp.edit().putInt("pos_x", v).apply()
        }

    var posY: Int
        get() = sp.getInt("pos_y", -1)
        set(v) {
            sp.edit().putInt("pos_y", v).apply()
        }

    fun isOn(m: Metric): Boolean = sp.getBoolean("m_" + m.key, m.defaultOn)

    fun setOn(m: Metric, on: Boolean) {
        sp.edit().putBoolean("m_" + m.key, on).apply()
    }
}
