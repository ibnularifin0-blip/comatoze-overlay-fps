package com.comatoze.overlay

import java.io.BufferedReader
import java.io.BufferedWriter
import java.io.InputStreamReader
import java.io.OutputStreamWriter
import java.util.concurrent.Callable
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit

/**
 * Shell root yang dibuka sekali dan dipakai berulang (KernelSU / Magisk).
 * available: null = belum diketahui, true = root ada, false = tidak ada / ditolak.
 */
object RootShell {
    private const val MARK = "__COMATOZE_END__"

    @Volatile
    var available: Boolean? = null
        private set

    @Volatile
    private var started = false

    @Volatile
    private var process: Process? = null

    @Volatile
    private var writer: BufferedWriter? = null

    @Volatile
    private var reader: BufferedReader? = null

    private val lock = Any()
    private val io = Executors.newSingleThreadExecutor()

    /** Panggil dari thread latar. Memblokir sampai pengguna menjawab permintaan root. */
    fun init() {
        if (started) return
        started = true
        available = try {
            val out = exec("id")
            out.contains("uid=0")
        } catch (e: Exception) {
            false
        }
    }

    fun reset() {
        close()
        available = null
        started = false
    }

    /** Menjalankan perintah sebagai root. Mengembalikan null bila root tidak ada atau timeout. */
    fun run(cmd: String, timeoutMs: Long = 3000): String? {
        if (available != true) return null
        val task = io.submit(Callable { exec(cmd) })
        return try {
            task.get(timeoutMs, TimeUnit.MILLISECONDS)
        } catch (e: Exception) {
            task.cancel(true)
            close()
            null
        }
    }

    private fun exec(cmd: String): String {
        synchronized(lock) {
            ensureOpen()
            val w = writer ?: throw IllegalStateException("shell tertutup")
            val r = reader ?: throw IllegalStateException("shell tertutup")
            try {
                w.write(cmd)
                w.write("\necho $MARK\n")
                w.flush()
                val sb = StringBuilder()
                while (true) {
                    val line = r.readLine() ?: break
                    if (line == MARK) break
                    sb.append(line).append('\n')
                }
                return sb.toString()
            } catch (e: Exception) {
                close()
                throw e
            }
        }
    }

    private fun ensureOpen() {
        val p = process
        if (p != null && p.isAlive && writer != null && reader != null) return
        close()
        val np = ProcessBuilder("su").redirectErrorStream(true).start()
        process = np
        writer = BufferedWriter(OutputStreamWriter(np.outputStream))
        reader = BufferedReader(InputStreamReader(np.inputStream))
    }

    private fun close() {
        try {
            process?.destroy()
        } catch (_: Exception) {
        }
        process = null
        writer = null
        reader = null
    }
}
