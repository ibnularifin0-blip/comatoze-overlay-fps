package com.comatoze.overlay

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PorterDuff
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.View
import android.widget.ImageView
import android.widget.TextView

object Colors {
    val BG: Int = Color.parseColor("#0B0D11")
    val SURFACE: Int = Color.parseColor("#14181F")
    val BORDER: Int = Color.parseColor("#232A34")
    val ACCENT: Int = Color.parseColor("#C8372D")
    val ACCENT_DIM: Int = Color.parseColor("#29C8372D")
    val TEXT: Int = Color.parseColor("#F4F6F8")
    val MUTED: Int = Color.parseColor("#9AA4B2")
    val HAIRLINE: Int = Color.parseColor("#24FFFFFF")
}

fun Context.dp(v: Int): Int = (v * resources.displayMetrics.density + 0.5f).toInt()

fun Context.rounded(fill: Int, radiusDp: Int, strokeColor: Int = 0, strokeDp: Int = 0): GradientDrawable {
    val d = GradientDrawable()
    d.setColor(fill)
    d.cornerRadius = dp(radiusDp).toFloat()
    if (strokeDp > 0) d.setStroke(dp(strokeDp), strokeColor)
    return d
}

fun Context.icon(res: Int, tint: Int): ImageView {
    val v = ImageView(this)
    v.setImageResource(res)
    v.setColorFilter(tint, PorterDuff.Mode.SRC_IN)
    return v
}

fun Context.label(
    text: String,
    sizeSp: Float,
    color: Int,
    bold: Boolean = false,
    mono: Boolean = false,
    spacing: Float = 0f
): TextView {
    val t = TextView(this)
    t.text = text
    t.textSize = sizeSp
    t.setTextColor(color)
    t.letterSpacing = spacing
    t.includeFontPadding = false
    t.typeface = Typeface.create(
        if (mono) Typeface.MONOSPACE else Typeface.DEFAULT,
        if (bold) Typeface.BOLD else Typeface.NORMAL
    )
    return t
}

/** Grafik batang kecil untuk riwayat FPS (mode Lengkap). */
class FpsGraph(context: Context) : View(context) {
    private val samples = ArrayDeque<Int>()
    private val maxBars = 30
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Colors.ACCENT
        alpha = 190
    }

    fun push(v: Int) {
        samples.addLast(v)
        while (samples.size > maxBars) samples.removeFirst()
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        if (samples.isEmpty()) return
        val top = (samples.maxOrNull() ?: 1).coerceAtLeast(1)
        val gap = context.dp(2).toFloat()
        val barW = (width - gap * (maxBars - 1)) / maxBars
        val offset = maxBars - samples.size
        samples.forEachIndexed { i, v ->
            val h = height * (v.toFloat() / top).coerceIn(0.08f, 1f)
            val x = (offset + i) * (barW + gap)
            canvas.drawRect(x, height - h, x + barW, height.toFloat(), paint)
        }
    }
}
