package com.comatoze.overlay

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.Icon
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import java.util.Locale
import java.util.concurrent.Executors
import java.util.concurrent.ScheduledExecutorService
import java.util.concurrent.TimeUnit
import kotlin.math.roundToInt

class OverlayService : Service() {

    companion object {
        @Volatile
        var running = false

        const val ACTION_STOP = "com.comatoze.overlay.STOP"
        private const val CHANNEL = "comatoze_overlay"
    }

    private lateinit var wm: WindowManager
    private lateinit var prefs: Prefs
    private lateinit var params: WindowManager.LayoutParams
    private var reader: StatsReader? = null
    private var executor: ScheduledExecutorService? = null
    private val ui = Handler(Looper.getMainLooper())

    private var root: View? = null
    private val values = mutableMapOf<Metric, TextView>()
    private var fpsHero: TextView? = null
    private var subTop: TextView? = null
    private var subBottom: TextView? = null
    private var graph: FpsGraph? = null
    private val recent = ArrayDeque<Int>()

    private val prefListener = SharedPreferences.OnSharedPreferenceChangeListener { _, key ->
        if (key != "pos_x" && key != "pos_y") {
            ui.post { rebuild() }
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        prefs = Prefs(this)
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        startAsForeground()

        if (!Settings.canDrawOverlays(this)) {
            stopSelf()
            return
        }

        running = true
        reader = StatsReader(this)
        Thread { RootShell.init() }.start()

        params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        )
        params.gravity = Gravity.TOP or Gravity.START
        params.x = if (prefs.posX >= 0) prefs.posX else dp(16)
        params.y = if (prefs.posY >= 0) prefs.posY else dp(12)
        if (Build.VERSION.SDK_INT >= 28) {
            params.layoutInDisplayCutoutMode =
                WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }

        rebuild()
        prefs.sp.registerOnSharedPreferenceChangeListener(prefListener)

        executor = Executors.newSingleThreadScheduledExecutor().also {
            it.scheduleWithFixedDelay({ tick() }, 0, 1, TimeUnit.SECONDS)
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf()
        }
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        running = false
        try {
            prefs.sp.unregisterOnSharedPreferenceChangeListener(prefListener)
        } catch (_: Exception) {
        }
        ui.removeCallbacksAndMessages(null)
        executor?.shutdownNow()
        root?.let {
            try {
                wm.removeView(it)
            } catch (_: Exception) {
            }
        }
        root = null
        RootShell.reset()
        super.onDestroy()
    }

    // ---------- Notifikasi foreground ----------

    private fun startAsForeground() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL, "Overlay", NotificationManager.IMPORTANCE_LOW)
        )
        val stopIntent = PendingIntent.getService(
            this, 0,
            Intent(this, OverlayService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val openIntent = PendingIntent.getActivity(
            this, 1,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE
        )
        val notification = Notification.Builder(this, CHANNEL)
            .setSmallIcon(R.drawable.ic_fps)
            .setContentTitle("Comatoze Overlay")
            .setContentText("Overlay aktif")
            .setContentIntent(openIntent)
            .addAction(
                Notification.Action.Builder(
                    Icon.createWithResource(this, R.drawable.ic_fps),
                    "Hentikan",
                    stopIntent
                ).build()
            )
            .setOngoing(true)
            .build()

        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(1, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(1, notification)
        }
    }

    // ---------- Pembacaan data ----------

    private fun tick() {
        val r = reader ?: return
        val enabled = Metric.values().filter { prefs.isOn(it) }.toMutableSet()
        if (prefs.style != 0) enabled.add(Metric.FPS)
        val s = try {
            r.read(enabled)
        } catch (e: Exception) {
            return
        }
        ui.post { render(s) }
    }

    private fun pct(v: Int?): String = if (v == null) "--" else "$v%"

    private fun render(s: Stats) {
        values[Metric.CPU]?.text = pct(s.cpu)
        values[Metric.GPU]?.text = pct(s.gpu)
        values[Metric.RAM]?.text = pct(s.ram)
        values[Metric.BATT]?.text = pct(s.battery)
        values[Metric.TEMP]?.text = s.tempC?.let { "${it.roundToInt()}°C" } ?: "--"

        val f = s.fps
        val fpsText = f?.toString() ?: "--"
        values[Metric.FPS]?.text = fpsText
        fpsHero?.text = fpsText

        if (f != null) {
            recent.addLast(f)
            while (recent.size > 10) recent.removeFirst()
            graph?.push(f)
        }
        if (prefs.style == 2) {
            val avg = if (recent.isEmpty()) "--" else recent.average().roundToInt().toString()
            subTop?.text = "AVG $avg"
        } else {
            subTop?.text = "FPS"
        }
        subBottom?.text =
            if (f != null && f > 0) String.format(Locale.US, "%.1f ms", 1000f / f) else "-- ms"
    }

    // ---------- Tampilan overlay ----------

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density + 0.5f).toInt()

    private fun panelColor(): Int = Color.argb(prefs.alpha * 255 / 100, 12, 14, 18)

    private fun rebuild() {
        root?.let {
            try {
                wm.removeView(it)
            } catch (_: Exception) {
            }
        }
        values.clear()
        fpsHero = null
        subTop = null
        subBottom = null
        graph = null

        val v = if (prefs.style == 0) buildMini() else buildCard(prefs.style == 2)
        root = v
        try {
            wm.addView(v, params)
        } catch (e: Exception) {
            stopSelf()
        }
    }

    private fun handleView(): ImageView {
        val h = ImageView(this)
        h.setImageResource(R.drawable.ic_move)
        h.setColorFilter(Colors.TEXT, android.graphics.PorterDuff.Mode.SRC_IN)
        h.setPadding(dp(6), dp(6), dp(6), dp(6))
        h.background = rounded(Colors.ACCENT, 7)
        h.setOnTouchListener(object : View.OnTouchListener {
            private var startX = 0
            private var startY = 0
            private var touchX = 0f
            private var touchY = 0f

            override fun onTouch(v: View, e: MotionEvent): Boolean {
                when (e.action) {
                    MotionEvent.ACTION_DOWN -> {
                        startX = params.x
                        startY = params.y
                        touchX = e.rawX
                        touchY = e.rawY
                    }
                    MotionEvent.ACTION_MOVE -> {
                        params.x = startX + (e.rawX - touchX).toInt()
                        params.y = startY + (e.rawY - touchY).toInt()
                        root?.let {
                            try {
                                wm.updateViewLayout(it, params)
                            } catch (_: Exception) {
                            }
                        }
                    }
                    MotionEvent.ACTION_UP -> {
                        prefs.posX = params.x
                        prefs.posY = params.y
                    }
                }
                return true
            }
        })
        return h
    }

    private fun metricCell(m: Metric, sizeSp: Float, iconDp: Int, padH: Int): LinearLayout {
        val cell = LinearLayout(this)
        cell.orientation = LinearLayout.HORIZONTAL
        cell.gravity = Gravity.CENTER_VERTICAL
        cell.setPadding(dp(padH), 0, dp(padH), 0)
        cell.addView(icon(m.iconRes, Colors.TEXT), LinearLayout.LayoutParams(dp(iconDp), dp(iconDp)))
        val tv = label("--", sizeSp, Colors.TEXT, bold = true, mono = true)
        values[m] = tv
        val lp = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.WRAP_CONTENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        )
        lp.leftMargin = dp(4)
        cell.addView(tv, lp)
        return cell
    }

    /** Gaya Mini: handle merah + satu bar horizontal. */
    private fun buildMini(): View {
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        row.addView(handleView(), LinearLayout.LayoutParams(dp(26), dp(26)))

        val enabled = Metric.values().filter { prefs.isOn(it) }
        if (enabled.isNotEmpty()) {
            val bar = LinearLayout(this)
            bar.orientation = LinearLayout.HORIZONTAL
            bar.gravity = Gravity.CENTER_VERTICAL
            bar.setPadding(dp(2), 0, dp(2), 0)
            bar.background = rounded(panelColor(), 7, Colors.HAIRLINE, 1)
            for (m in enabled) bar.addView(metricCell(m, 11f, 14, 6))
            val lp = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                dp(26)
            )
            lp.leftMargin = dp(6)
            row.addView(bar, lp)
        }
        return row
    }

    /** Gaya Standar dan Lengkap: kartu dengan FPS besar. */
    private fun buildCard(full: Boolean): View {
        val card = LinearLayout(this)
        card.orientation = LinearLayout.VERTICAL
        card.setPadding(dp(12), dp(10), dp(12), dp(12))
        card.minimumWidth = dp(168)
        card.background = rounded(panelColor(), 10, Colors.HAIRLINE, 1)

        val top = LinearLayout(this)
        top.orientation = LinearLayout.HORIZONTAL
        top.gravity = Gravity.CENTER_VERTICAL
        top.addView(icon(R.drawable.ic_fps, Colors.ACCENT), LinearLayout.LayoutParams(dp(20), dp(20)))

        val hero = label("--", 30f, Colors.ACCENT, bold = true, mono = true)
        fpsHero = hero
        val heroLp = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.WRAP_CONTENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        )
        heroLp.leftMargin = dp(8)
        top.addView(hero, heroLp)

        val side = LinearLayout(this)
        side.orientation = LinearLayout.VERTICAL
        side.gravity = Gravity.END
        val st = label("FPS", 10f, Colors.MUTED, mono = true, spacing = 0.08f)
        val sb = label("-- ms", 11f, Colors.TEXT, mono = true)
        subTop = st
        subBottom = sb
        side.addView(st)
        side.addView(sb)
        val sideLp = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        sideLp.leftMargin = dp(10)
        sideLp.rightMargin = dp(10)
        top.addView(side, sideLp)

        top.addView(handleView(), LinearLayout.LayoutParams(dp(26), dp(26)))
        card.addView(top)

        if (full) {
            val g = FpsGraph(this)
            graph = g
            val gl = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(26))
            gl.topMargin = dp(8)
            card.addView(g, gl)
        }

        val divider = View(this)
        divider.setBackgroundColor(Colors.HAIRLINE)
        val dl = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 1)
        dl.topMargin = dp(10)
        card.addView(divider, dl)

        val metrics = Metric.values().filter { it != Metric.FPS && prefs.isOn(it) }
        for (pair in metrics.chunked(2)) {
            val row = LinearLayout(this)
            row.orientation = LinearLayout.HORIZONTAL
            for (m in pair) {
                row.addView(metricCell(m, 12f, 14, 0), LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
            }
            if (pair.size == 1) {
                row.addView(View(this), LinearLayout.LayoutParams(0, 1, 1f))
            }
            val rl = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
            rl.topMargin = dp(8)
            card.addView(row, rl)
        }
        return card
    }
}
