package com.comatoze.overlay

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private lateinit var prefs: Prefs
    private lateinit var statusDot: View
    private lateinit var statusText: TextView
    private lateinit var actionBtn: TextView
    private lateinit var rootInfo: TextView
    private val ui = Handler(Looper.getMainLooper())

    private val refresher = object : Runnable {
        override fun run() {
            refreshUi()
            ui.postDelayed(this, 1000)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = Prefs(this)
        setContentView(buildContent())
    }

    override fun onResume() {
        super.onResume()
        ui.post(refresher)
    }

    override fun onPause() {
        super.onPause()
        ui.removeCallbacks(refresher)
    }

    // ---------- Susunan layar ----------

    private fun buildContent(): View {
        val scroll = ScrollView(this)
        scroll.isFillViewport = true
        scroll.setBackgroundColor(Colors.BG)

        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(20), dp(28), dp(20), dp(28))
        scroll.addView(
            col,
            FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.WRAP_CONTENT
            )
        )

        col.addView(buildHeader())
        col.addView(section("Gaya"), topMargin(22))
        col.addView(buildStyleSwitch(), topMargin(8))
        col.addView(section("Metrik"), topMargin(22))
        col.addView(buildMetricGrid(), topMargin(8))
        col.addView(section("Transparansi"), topMargin(22))
        col.addView(buildOpacity(), topMargin(4))

        rootInfo = label("", 12f, Colors.MUTED)
        rootInfo.setLineSpacing(0f, 1.2f)
        col.addView(rootInfo, topMargin(14))

        val spacer = View(this)
        col.addView(spacer, LinearLayout.LayoutParams(1, 0, 1f))

        actionBtn = label("MULAI OVERLAY", 16f, Colors.TEXT, bold = true, spacing = 0.14f)
        actionBtn.gravity = Gravity.CENTER
        actionBtn.background = rounded(Colors.ACCENT, 6)
        actionBtn.isClickable = true
        actionBtn.setOnClickListener { toggle() }
        col.addView(
            actionBtn,
            LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(56)).apply {
                topMargin = dp(22)
            }
        )
        return scroll
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density + 0.5f).toInt()

    private fun topMargin(dpValue: Int): LinearLayout.LayoutParams {
        val lp = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        )
        lp.topMargin = dp(dpValue)
        return lp
    }

    private fun section(title: String): TextView =
        label(title.uppercase(), 12f, Colors.MUTED, bold = true, spacing = 0.14f)

    private fun buildHeader(): View {
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL

        val logo = icon(R.drawable.ic_fps, Colors.TEXT)
        logo.setPadding(dp(8), dp(8), dp(8), dp(8))
        logo.background = rounded(Colors.ACCENT, 8)
        row.addView(logo, LinearLayout.LayoutParams(dp(36), dp(36)))

        val names = LinearLayout(this)
        names.orientation = LinearLayout.VERTICAL
        names.addView(label("COMATOZE", 20f, Colors.TEXT, bold = true, spacing = 0.14f))
        val sub = label("OVERLAY", 11f, Colors.MUTED, spacing = 0.3f)
        names.addView(sub, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.WRAP_CONTENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = dp(3) })
        row.addView(
            names,
            LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply {
                leftMargin = dp(12)
            }
        )

        val pill = LinearLayout(this)
        pill.orientation = LinearLayout.HORIZONTAL
        pill.gravity = Gravity.CENTER_VERTICAL
        pill.setPadding(dp(10), dp(6), dp(10), dp(6))
        pill.background = rounded(Colors.SURFACE, 20, Colors.BORDER, 1)
        statusDot = View(this)
        statusDot.background = rounded(Colors.MUTED, 4)
        pill.addView(statusDot, LinearLayout.LayoutParams(dp(8), dp(8)))
        statusText = label("Nonaktif", 12f, Colors.MUTED, bold = true)
        pill.addView(statusText, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.WRAP_CONTENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply { leftMargin = dp(6) })
        row.addView(pill)
        return row
    }

    private fun buildStyleSwitch(): View {
        val names = listOf("Mini", "Standar", "Lengkap")
        val wrap = LinearLayout(this)
        wrap.orientation = LinearLayout.HORIZONTAL
        wrap.setPadding(dp(4), dp(4), dp(4), dp(4))
        wrap.background = rounded(Colors.SURFACE, 12, Colors.BORDER, 1)

        val tabs = mutableListOf<TextView>()
        fun paint() {
            for ((i, t) in tabs.withIndex()) {
                val on = prefs.style == i
                t.background = rounded(if (on) Colors.ACCENT else 0, 8)
                t.setTextColor(if (on) Colors.TEXT else Colors.MUTED)
            }
        }
        for ((i, n) in names.withIndex()) {
            val t = label(n, 14f, Colors.MUTED, bold = true)
            t.gravity = Gravity.CENTER
            t.isClickable = true
            t.setOnClickListener {
                prefs.style = i
                paint()
            }
            tabs.add(t)
            wrap.addView(t, LinearLayout.LayoutParams(0, dp(40), 1f))
        }
        paint()
        return wrap
    }

    private fun buildMetricGrid(): View {
        val grid = LinearLayout(this)
        grid.orientation = LinearLayout.VERTICAL
        for (rowMetrics in Metric.values().toList().chunked(3)) {
            val row = LinearLayout(this)
            row.orientation = LinearLayout.HORIZONTAL
            for ((i, m) in rowMetrics.withIndex()) {
                val lp = LinearLayout.LayoutParams(0, dp(68), 1f)
                if (i > 0) lp.leftMargin = dp(8)
                row.addView(metricTile(m), lp)
            }
            val rl = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
            if (grid.childCount > 0) rl.topMargin = dp(8)
            grid.addView(row, rl)
        }
        return grid
    }

    private fun metricTile(m: Metric): View {
        val tile = LinearLayout(this)
        tile.orientation = LinearLayout.VERTICAL
        tile.gravity = Gravity.CENTER
        tile.isClickable = true
        val ic = icon(m.iconRes, Colors.TEXT)
        val tv = label(m.label, 12f, Colors.TEXT, bold = true)
        tile.addView(ic, LinearLayout.LayoutParams(dp(18), dp(18)))
        tile.addView(tv, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.WRAP_CONTENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = dp(6) })

        fun paint() {
            val on = prefs.isOn(m)
            tile.background = if (on) {
                rounded(Colors.ACCENT_DIM, 10, Colors.ACCENT, 1)
            } else {
                rounded(Colors.SURFACE, 10, Colors.BORDER, 1)
            }
            val c = if (on) Colors.TEXT else Colors.MUTED
            ic.setColorFilter(c, android.graphics.PorterDuff.Mode.SRC_IN)
            tv.setTextColor(c)
        }
        paint()
        tile.setOnClickListener {
            prefs.setOn(m, !prefs.isOn(m))
            paint()
        }
        return tile
    }

    private fun buildOpacity(): View {
        val wrap = LinearLayout(this)
        wrap.orientation = LinearLayout.VERTICAL

        val valueText = label("${prefs.alpha}%", 12f, Colors.TEXT, bold = true, mono = true)
        valueText.gravity = Gravity.END
        wrap.addView(valueText, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        ))

        val bar = SeekBar(this)
        bar.max = 70
        bar.progress = prefs.alpha - 30
        val tint = ColorStateList.valueOf(Colors.ACCENT)
        bar.progressTintList = tint
        bar.thumbTintList = tint
        bar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar, progress: Int, fromUser: Boolean) {
                valueText.text = "${progress + 30}%"
            }

            override fun onStartTrackingTouch(sb: SeekBar) {}

            override fun onStopTrackingTouch(sb: SeekBar) {
                prefs.alpha = sb.progress + 30
            }
        })
        wrap.addView(bar, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            dp(44)
        ))
        return wrap
    }

    // ---------- Aksi ----------

    private fun toggle() {
        if (OverlayService.running) {
            startService(Intent(this, OverlayService::class.java).setAction(OverlayService.ACTION_STOP))
        } else {
            if (!Settings.canDrawOverlays(this)) {
                Toast.makeText(this, "Izinkan \"Tampil di atas aplikasi lain\" dulu", Toast.LENGTH_LONG).show()
                startActivity(
                    Intent(
                        Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:$packageName")
                    )
                )
                return
            }
            if (Build.VERSION.SDK_INT >= 33 &&
                checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
            ) {
                requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
            }
            startForegroundService(Intent(this, OverlayService::class.java))
        }
        ui.postDelayed({ refreshUi() }, 300)
    }

    private fun refreshUi() {
        val on = OverlayService.running
        statusText.text = if (on) "Aktif" else "Nonaktif"
        statusText.setTextColor(if (on) Colors.TEXT else Colors.MUTED)
        statusDot.background = rounded(if (on) Colors.ACCENT else Colors.MUTED, 4)
        actionBtn.text = if (on) "HENTIKAN OVERLAY" else "MULAI OVERLAY"

        rootInfo.text = when {
            !on -> "Tanpa root hanya RAM, suhu, dan baterai yang terbaca. Dengan root (KernelSU) CPU, GPU, dan FPS game ikut terbaca."
            RootShell.available == null -> "Meminta akses root…"
            RootShell.available == true -> "Root aktif. CPU, GPU, dan FPS dibaca jika perangkat mendukung."
            else -> "Root tidak tersedia. Hanya RAM, suhu, dan baterai yang terbaca."
        }
    }
}
